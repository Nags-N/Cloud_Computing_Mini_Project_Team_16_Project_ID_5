// fsm.go
package main

import (
	"io"
	"log"

	"github.com/hashicorp/raft"
)

type fsm struct{}

func (f *fsm) Apply(l *raft.Log) interface{} {
	log.Printf("Applying: %s", string(l.Data))
	return nil
}

func (f *fsm) Snapshot() (raft.FSMSnapshot, error) {
	return &noopSnapshot{}, nil
}

func (f *fsm) Restore(io.ReadCloser) error {
	return nil
}

type noopSnapshot struct{}

func (n *noopSnapshot) Persist(sink raft.SnapshotSink) error {
	defer sink.Cancel()
	return nil
}

func (n *noopSnapshot) Release() {}
