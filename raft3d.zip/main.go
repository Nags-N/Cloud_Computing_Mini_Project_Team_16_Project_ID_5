// main.go
package main

import (
	"flag"
	"fmt"
	"log"
	//"net"
	"net/http"
	"os"
	//"strings"
	"time"

	"github.com/hashicorp/raft"
	"github.com/hashicorp/raft-boltdb"
)

type Node struct {
	id    string
	raft  *raft.Raft
	store *fsm
}

func main() {
	// === CLI flags ===
	nodeID := flag.String("id", "", "Unique ID for this node")
	raftPort := flag.String("raft-port", "12000", "Port for Raft communication")
	httpPort := flag.String("http-port", "8080", "Port for HTTP server")
	joinAddr := flag.String("join", "", "Address to join an existing cluster")

	flag.Parse()

	if *nodeID == "" {
		log.Fatal("You must provide --id for this node.")
	}

	// === Setup dirs ===
	dataDir := fmt.Sprintf("raft-data-%s", *nodeID)
	os.MkdirAll(dataDir, 0700)

	// === Create Raft config ===
	config := raft.DefaultConfig()
	config.LocalID = raft.ServerID(*nodeID)

	// Log store
	logStore, err := raftboltdb.NewBoltStore(fmt.Sprintf("%s/log.db", dataDir))
	if err != nil {
		log.Fatalf("log store error: %s", err)
	}

	stableStore, err := raftboltdb.NewBoltStore(fmt.Sprintf("%s/stable.db", dataDir))
	if err != nil {
		log.Fatalf("stable store error: %s", err)
	}

	snapshotStore, err := raft.NewFileSnapshotStore(dataDir, 1, os.Stdout)
	if err != nil {
		log.Fatalf("snapshot store error: %s", err)
	}

	// Transport layer
	addr := fmt.Sprintf("127.0.0.1:%s", *raftPort)
	transport, err := raft.NewTCPTransport(addr, nil, 3, 10*time.Second, os.Stdout)
	if err != nil {
		log.Fatalf("transport error: %s", err)
	}

	node := &Node{
		id:    *nodeID,
		store: &fsm{},
	}

	// Init Raft
	r, err := raft.NewRaft(config, node.store, logStore, stableStore, snapshotStore, transport)
	if err != nil {
		log.Fatalf("raft init error: %s", err)
	}
	node.raft = r

	// Bootstrap or Join
	if *joinAddr == "" {
		log.Println("Bootstrapping single-node cluster...")
		r.BootstrapCluster(raft.Configuration{
			Servers: []raft.Server{
				{ID: config.LocalID, Address: transport.LocalAddr()},
			},
		})
	} else {
		// Join existing cluster via HTTP
		joinURL := fmt.Sprintf("http://%s/join?peerID=%s&peerAddr=%s", *joinAddr, *nodeID, addr)
		resp, err := http.Get(joinURL)
		if err != nil {
			log.Fatalf("Failed to join cluster: %v", err)
		}
		resp.Body.Close()
		log.Println("Joined cluster via", joinURL)
	}

	// HTTP Handlers
	http.HandleFunc("/raft/state", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(node.raft.State().String()))
	})

	http.HandleFunc("/join", func(w http.ResponseWriter, r *http.Request) {
		peerID := r.URL.Query().Get("peerID")
		peerAddr := r.URL.Query().Get("peerAddr")
		if peerID == "" || peerAddr == "" {
			http.Error(w, "Missing peerID or peerAddr", http.StatusBadRequest)
			return
		}
		log.Printf("Received join request from %s (%s)", peerID, peerAddr)
		f := node.raft.AddVoter(raft.ServerID(peerID), raft.ServerAddress(peerAddr), 0, 0)
		if err := f.Error(); err != nil {
			http.Error(w, "Join failed: "+err.Error(), http.StatusInternalServerError)
			return
		}
		fmt.Fprintf(w, "Joined %s", peerID)
	})

	log.Println("HTTP server on port", *httpPort)
	log.Fatal(http.ListenAndServe(":"+*httpPort, nil))
}
